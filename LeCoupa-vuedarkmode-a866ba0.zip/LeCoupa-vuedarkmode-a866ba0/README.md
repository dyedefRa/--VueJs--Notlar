<p align="center" style="background: #1b2431; padding: 20px 0;">
  <a href="https://www.vuedarkmode.com" target="_blank">
    <img width="100%" src="https://raw.githubusercontent.com/LeCoupa/vuedarkmode/master/static/images/docs/banner.svg?sanitize=true">
  </a>
</p>

<h2 align="center">Vue Dark Mode</h2>

<p align="center">A minimalist dark design system for vue.js 👩‍🎨👨‍🎨</p>
