# Vue.js example docs

Testing Vue.js v.1.0 guided by examples from official Vue.js documentation
