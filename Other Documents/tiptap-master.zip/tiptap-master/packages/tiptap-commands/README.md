# tiptap-commands
This is a collection of commands for [tiptap](https://www.npmjs.com/package/tiptap).

[![](https://img.shields.io/npm/v/tiptap-commands.svg?label=version)](https://www.npmjs.com/package/tiptap-commands)
[![](https://img.shields.io/npm/dm/tiptap-commands.svg)](https://npmcharts.com/compare/tiptap-commands?minimal=true)
[![](https://img.shields.io/npm/l/tiptap-commands.svg)](https://www.npmjs.com/package/tiptap-commands)
[![](http://img.badgesize.io/https://unpkg.com/tiptap-commands/dist/commands.min.js?compression=gzip&label=size&colorB=000000)](https://www.npmjs.com/package/tiptap-commands)