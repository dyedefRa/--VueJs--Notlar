import { Plugin } from 'prosemirror-state'

export default Plugin
