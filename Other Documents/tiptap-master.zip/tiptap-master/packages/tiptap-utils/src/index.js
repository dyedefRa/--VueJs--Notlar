export { default as getMarkAttrs } from './utils/getMarkAttrs'
export { default as markIsActive } from './utils/markIsActive'
export { default as nodeIsActive } from './utils/nodeIsActive'
