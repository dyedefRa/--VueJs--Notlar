<template>
	<div class="subnavigation">
		<router-link class="subnavigation__link" to="/">
			Basic
		</router-link>
		<router-link class="subnavigation__link" to="/menu-bubble">
			Menu Bubble
		</router-link>
		<router-link class="subnavigation__link" to="/floating-menu">
			Floating Menu
		</router-link>
		<router-link class="subnavigation__link" to="/links">
			Links
		</router-link>
		<router-link class="subnavigation__link" to="/images">
			Images
		</router-link>
		<router-link class="subnavigation__link" to="/text-align">
			Text Align
		</router-link>
		<router-link class="subnavigation__link" to="/hiding-menu-bar">
			Hiding Menu Bar
		</router-link>
		<router-link class="subnavigation__link" to="/todo-list">
			Todo List
		</router-link>
		<router-link class="subnavigation__link" to="/suggestions">
			Suggestions
		</router-link>
		<router-link class="subnavigation__link" to="/markdown-shortcuts">
			Markdown Shortcuts
		</router-link>
		<router-link class="subnavigation__link" to="/code-highlighting">
			Code Highlighting
		</router-link>
		<router-link class="subnavigation__link" to="/read-only">
			Read-Only
		</router-link>
		<router-link class="subnavigation__link" to="/embeds">
			Embeds
		</router-link>
		<router-link class="subnavigation__link" to="/placeholder">
			Placeholder
		</router-link>
		<router-link class="subnavigation__link" to="/export">
			Export HTML or JSON
		</router-link>
	</div>
</template>

<style lang="scss" src="./style.scss" scoped></style>