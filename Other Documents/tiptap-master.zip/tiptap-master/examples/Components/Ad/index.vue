<template>
	<a class="ad" href="https://scrumpy.io/" target="_blank">
		<img class="ad__image" src="https://drop.philipp-kuehn.com/api98lPyuw.png" alt="Scrumpy. Agile Planning, Made Simple. Get Started." />
	</a>
</template>

<style lang="scss" src="./style.scss" scoped></style>
